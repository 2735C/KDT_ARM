#include "device_driver.h"

#define LCDW			(320)
#define LCDH			(240)
#define X_MIN	 		(0)
#define X_MAX	 		(LCDW - 1)
#define Y_MIN	 		(0)
#define Y_MAX	 		(LCDH - 1)

#define TIMER_PERIOD	(10)
#define RIGHT			(1)
#define LEFT			(-1)
#define DOWN			(0)
#define UP			    (1)

//item size & 속도
#define WOLF_STEP		(15)
#define WOLF_SIZE_X		(15)
#define WOLF_SIZE_Y		(15)
#define RED_STEP		(15)
#define RED_SIZE_X		(15)
#define RED_SIZE_Y		(15)
#define FRUIT_STEP		(15)
#define FRUIT_SIZE_X	(15)
#define FRUIT_SIZE_Y	(15)




//item color
#define BACK_COLOR		(5)
#define WOLF_COLOR		(3)
#define RED_COLOR		(0)
#define FRUIT_COLOR		(1)

#define GAME_OVER		(1)




//move 활성화
static int wolf_active = 0;

typedef struct
{
	int x,y;
	int w,h;
	int ci;
	int dir;
}QUERY_DRAW;

typedef struct
{
	int x,y;
	int w,h;
	int ci;
	int xdir;
	int ydir;
}OBJECT_DRAW;

#define MAX_WOLF 2
static QUERY_DRAW fruit;
static QUERY_DRAW red;
static OBJECT_DRAW wolf;

static volatile int score;
#define GHP (score / 5)
static unsigned short color[] = {RED, YELLOW, GREEN, GREY, WHITE, BLACK};

static int FRUIT_Move(void);


static int Check_Collision(void)
{
	int col = 0;
	int get_fruit= 0;
	

	if((wolf.x >= red.x) && ((red.x + RED_STEP) >= wolf.x)) col |= 1<<0;
	else if((wolf.x < red.x) && ((wolf.x + WOLF_STEP) >= red.x)) col |= 1<<0;
	
	if((wolf.y >= red.y) && ((red.y + RED_STEP) >= wolf.y)) col |= 1<<1;
	else if((wolf.y < red.y) && ((wolf.y + WOLF_STEP) >= red.y)) col |= 1<<1;
	
	if((fruit.x >= red.x) && ((red.x + RED_STEP) >= fruit.x)) col |= 1<<2;
	else if((fruit.x < red.x) && ((fruit.x + FRUIT_STEP) >= red.x)) col |= 1<<2;
	
	if((fruit.y >= red.y) && ((red.y + RED_STEP) >= fruit.y)) col |= 1<<3;
	else if((fruit.y < red.y) && ((fruit.y + FRUIT_STEP) >= red.y)) col |= 1<<3;

	if((col & 0x3) == 3)
	{
		Uart_Printf("SCORE = %d\n", score);	
		return GAME_OVER;
	}

	if(((col>>2) &0x3 )== 3)
	{
		score+=3;
		Lcd_Printf(230,0,RED,WHITE,2,2,"GHP:%d", GHP);
		Uart_Printf("score: %d\n", score);

		fruit.ci = BACK_COLOR;
		red.ci = RED_COLOR;
		fruit.y = LCDH;
	}
	return 0;
}

static int Wolf_Move(void)
{
	if (!wolf_active){return 0;}
	else
	{
		wolf.xdir=(rand()%2 ? RIGHT: LEFT);
		if((wolf.x + WOLF_STEP * wolf.xdir >= X_MAX) || (wolf.x + WOLF_STEP * wolf.xdir  <= X_MIN)) wolf.xdir = -wolf.xdir;
		wolf.x += WOLF_STEP * wolf.xdir;
		wolf.ydir=(rand()%2 ? RIGHT: LEFT);
		if((wolf.y + WOLF_STEP * wolf.ydir >= Y_MAX) || (wolf.y + WOLF_STEP * wolf.ydir <= Y_MIN)) wolf.ydir = -wolf.ydir;
		wolf.y += WOLF_STEP * wolf.ydir;
		return Check_Collision();
	}
}

static int FRUIT_Move(void)
{
	if (fruit.y < LCDH - fruit.h)
	{fruit.y += FRUIT_STEP * fruit.dir;}
	return Check_Collision();
}

static void k0(void)
{
	if(red.y > Y_MIN) red.y -= RED_STEP;
}

static void k1(void)
{
	if(red.y + red.h < Y_MAX) red.y += RED_STEP;
}

static void k2(void)
{
	if(red.x > X_MIN) red.x -= RED_STEP;
}

static void k3(void)
{
	if(red.x + red.w < X_MAX) red.x += RED_STEP;
}

static int RED_Move(int k)
{
	// UP(0), DOWN(1), LEFT(2), RIGHT(3)
	static void (*key_func[])(void) = {k0, k1, k2, k3};
	if(k <= 3) key_func[k]();
	return Check_Collision();
}


static void Game_Init(void)
{
	int i;
	score = 0;
	Lcd_Clr_Screen();
	red.x = 150; red.y = 220; red.w = RED_SIZE_X; red.h = RED_SIZE_Y; red.ci = RED_COLOR; red.dir = UP;
	Lcd_Draw_Box(red.x, red.y, red.w, red.h, color[red.ci]);

}

static void Draw_Object(QUERY_DRAW * obj)
{
	Lcd_Draw_Box(obj->x, obj->y, obj->w, obj->h, color[obj->ci]);
}

extern volatile int TIM4_expired;
extern volatile int USART1_rx_ready;
extern volatile int USART1_rx_data;
extern volatile int Jog_key_in;
extern volatile int Jog_key;
extern volatile int sec_3;
extern volatile int sec_7;
extern volatile int sec_10;
extern volatile int elapsed_ms;
extern volatile int elapsed_sec;
extern volatile int num;
extern volatile int game_time;
extern volatile int HP;
extern volatile int game_over;
extern volatile int msec_5;



void System_Init(void)
{
	Clock_Init();
	LED_Init();
	Key_Poll_Init();
	Uart1_Init(115200);

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 7<<16;
}


static void FRUIT_EN(void)
{
	if(sec_3 ==1)
	{
		sec_3 =0;
		fruit.x = rand()%319; fruit.y = 0; fruit.w = FRUIT_SIZE_X; fruit.h = FRUIT_SIZE_Y; fruit.ci = FRUIT_COLOR; fruit.dir = RIGHT; 
		Lcd_Draw_Box(fruit.x, fruit.y, fruit.w, fruit.h, color[fruit.ci]);
	}
}

static void TARGET_EN(void)
{
	if(sec_10 ==1)
	{
		sec_10 =0;
	
		wolf_active = 1;
		{
			wolf.x = rand()%319; wolf.y = rand()%239; wolf.w = WOLF_SIZE_X; wolf.h = WOLF_SIZE_Y; wolf.ci = WOLF_COLOR; 
			Lcd_Draw_Box(wolf.x, wolf.y, wolf.w, wolf.h, color[wolf.ci]);
		}
	}
}


static void Target_DIS(void)
{	
	if(sec_7 ==1)		
	{
		sec_7=0;
		wolf.ci = BACK_COLOR;
		Draw_Object(&wolf);		
		wolf.y = LCDH;
		wolf_active = 0;
		Uart1_Printf("wolf stop");

	}
}

#define DIPLAY_MODE		3

void Main(void)
{
	

	System_Init();
	Uart_Printf("The Wolf & Red Riding Hood\n");
	Lcd_Init(DIPLAY_MODE);
	
	Jog_Poll_Init();
	Jog_ISR_Enable(1);
	Uart1_RX_Interrupt_Enable(1);

	for(;;)
	{
		Game_Init();
		
		TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD*10);
		Lcd_Printf(230,0,RED,WHITE,2,2,"GHP:%d", GHP);

		for(;;)
		{
			
			Lcd_Printf(230,0,RED,WHITE,2,2,"GHP:%d", GHP);

			game_over = 0;
			//Target_DIS();
			FRUIT_EN();
			TARGET_EN();

			if(Jog_key_in) 
			{
				red.ci = BACK_COLOR;
				Draw_Object(&red);
				game_over = RED_Move(Jog_key);
				if(red.y < LCDH - red.h)
				{red.ci = RED_COLOR;
				Draw_Object(&red);}
				Jog_key_in = 0;
			}

			if(TIM4_expired) 
			{
				
				fruit.ci = BACK_COLOR;
				Draw_Object(&fruit);
				game_over |= FRUIT_Move();
				if(fruit.y < LCDH - fruit.h)
				{fruit.ci = FRUIT_COLOR;
				Draw_Object(&fruit);}

				wolf.ci = BACK_COLOR;
				Draw_Object(&wolf);
				game_over |= Wolf_Move();
				
				{if(wolf.y < LCDH - wolf.h)				
				{wolf.ci = WOLF_COLOR;
				Draw_Object(&wolf);}}

				TIM4_expired = 0;
				
			}

			if((game_over==1) || (HP ==0))
			{
				TIM4_Repeat_Interrupt_Enable(0, 0);
				if (GHP <4)
				{
					Uart_Printf("You haven't collected enough of Grandma's medicine.\n");
					Uart_Printf("Hunt the wolves and take revenge.\n");
				}
				else 
				{
					Uart_Printf("You saved your grandmother's life.\n");
				}
				Uart_Printf("Game Over, Please press RESET to continue.\n");
				Lcd_Printf(85,100,GREEN,WHITE,2,2,"GAME OVER");

				Jog_Wait_Key_Pressed();
				Jog_Wait_Key_Released();
				game_time=50; HP =50; elapsed_sec=0; elapsed_ms=0; num=0; sec_3=0; sec_7=0; sec_10=0;

				break; 
			}
		}break;
	}
}
